#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "protocoleTicTacToe.h"


int attendRequeteClient(int sockConx);

TypPartieReq recoitRequetePartieClient(int sockConx,int sockTrans);

void envoieReponsePartieClient(int sockConx,int sockTrans,TypPartieRep repPartJ);

TypPartieRep remplieRepPartieClient(int j,TypPartieReq typPReqJ1,TypPartieReq typPReqJ2);