#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "fonctionsSocket.h"
#include "fonctionsClient.h"
#include "protocoleTicTacToe.h"

 
main(int argc, char **argv){

    int sock,err, i;             
    TypIdRequest typR = PARTIE;
    TypPartieReq typPartReq;
    TypPartieRep typPartRep;
    char* nomJ;
    TypSymbol  symb;  

    if (argc != 3) {
        printf("usage : client nom_machine no_port\n");
        exit(1);
    }
  
    char* nomMachine = argv[1];
    int nbPort = atoi(argv[2]);

    sock =  socketClient(nomMachine, nbPort);


    printf("Début du jeu, envoi d'une demande de partie au serveur : \n");
    nomJ = demandeNom();
    typPartReq = remplieRequetePartie(nomJ);
    envoieRequetePartie(typPartReq,sock);
    typPartRep = recoitReponsePartie(sock);
    afficheInfoPartie(typPartRep);
    shutdown(sock, 2);
    close(sock);
}
 

