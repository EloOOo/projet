#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "fonctionsServeur.h"


int attendRequeteClient(int sockConx){
    int sockTrans = accept(sockConx, NULL, NULL);
    if (sockTrans < 0) {
        perror("serveur :  erreur sur accept");
        close(sockConx);
        exit(3);
    }
    return sockTrans;
}

TypPartieReq recoitRequetePartieClient(int sockConx,int sockTrans){
	TypPartieReq typP;
	int err;
	err = recv(sockTrans, &typP, sizeof(typP), 0);
    if (err < 0) {
        perror("serveur : erreur dans la reception");
        shutdown(sockTrans, 2); 
        close(sockTrans);
        close(sockConx);
        exit(4);
    }
    return typP;
}

void envoieReponsePartieClient(int sockConx,int sockTrans,TypPartieRep repPartJ ){
	int err = send(sockTrans, &repPartJ, sizeof(repPartJ), 0);
    if (err <= 0) {
        perror("serveur : erreur sur le send");
        shutdown(sockTrans, 2); 
        close(sockTrans);
        close(sockConx);
        exit(3);
    }
}

TypPartieRep remplieRepPartieClient(int j,TypPartieReq typPReqJ1,TypPartieReq typPReqJ2){
	TypPartieRep repPartJ;
	if(j == 1){
		repPartJ.symb = CROIX;
		strcpy(repPartJ.nomAdvers,typPReqJ2.nomJoueur);
		repPartJ.err = ERR_OK;
	}
	else {
		repPartJ.symb = ROND;
		strcpy(repPartJ.nomAdvers,typPReqJ1.nomJoueur);
		repPartJ.err = ERR_OK;
	}
	
    return repPartJ;
}